use AssessmentDB_Test

/*Drop all these tables and views in the named database.  Be sure to 
select correct database*/
/*Number of tables: 18*/
drop table Answers 
drop table Assessments 
drop table AssessmentsQuestions 
drop table AssessmentsStudents 
drop table Classes 
drop table ClassesStudents 
drop table ClassesSubjects 
drop table [Messages] 
drop table Questions 
drop table Schools 
drop table StaffMembers 
drop table Standards 
drop table Students 
drop table StudentsTesting 
drop table Subjects 
drop table TeachersClasses 
drop table TeachersSubjects 
drop table TeachersSchools 

/*Give permissions  user on views*/
/*Number of views: 7*/
drop view vuAssessments 
drop view  vuAssessmentsQuestions 
drop view  vuClasses 
drop view  vuQuestions 
drop view  vuStaffMembers 
drop view vuStudents 
drop view  vuSubjects 

/*revoke commands*/
/*
revoke insert, update on StaffMembers from sathi
*/