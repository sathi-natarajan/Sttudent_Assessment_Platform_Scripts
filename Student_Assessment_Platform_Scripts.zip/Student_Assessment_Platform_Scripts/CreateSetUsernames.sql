Use AssessmentDB 

--Fix the Username for Teachers as 'TeacherX' where X is their system-generated ID
UPDATE Teachers SET Username='Teacher' + cast(TeacherID as Varchar)

--Fix the Username for Students as '[First5Charsof1stname][1st2charsofLastname]' - to follow 5x2 rule
UPDATE Students SET Username=left(Firstname,5)+LEFT(Lastname,2)
