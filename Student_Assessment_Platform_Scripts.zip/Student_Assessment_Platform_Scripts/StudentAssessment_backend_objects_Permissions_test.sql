use AssessmentDB

/*Give permissions to test user on tables
ex: grant select, insert, update on StaffMembers to sathi*/
/*Number of tables: 10*/
grant select on Admins to test
grant select,INSERT,UPDATE,delete on Classes to test
grant select,INSERT,delete on ClassesSubjects to test
grant select on GradeLevels to test
grant select on Schools to test
grant select,insert,delete,Update on Students to test
grant select,insert,delete,Update on Students_Classes to test
grant select,INSERT,UPDATE,delete on Subjects to test
grant select,insert,delete,Update on Teachers to test
grant select,INSERT,delete on TeachersClasses to test


/*Give permissions to test user on views*/
/*Number of views: 2*/
grant select on vuStudents to test
grant select on vuTeachers to test

--grant select on vuAssessments to test
--grant select on vuAssessmentsQuestions to test
--grant select on vuClasses to test
--grant select on vuQuestions to test
--grant select on vuSubjects to test

/*revoke commands*/
/*
revoke insert, update on StaffMembers from sathi
*/