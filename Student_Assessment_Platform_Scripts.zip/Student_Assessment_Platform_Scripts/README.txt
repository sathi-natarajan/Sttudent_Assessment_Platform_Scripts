1.Run the script StudentAssessment_backend_objects_drop_objects.sql first.  It will show you some errors saying so-and-so object is not
found.  Ignore them.

2.Secondly, run the script "StudentAssessment_backend_objects.sql".  This will create necessary tables and views.

3.Lastly, run the script "StudentAssessment_backend_objects_Permissions_test.sql".  This will give access permissions to these objects.
