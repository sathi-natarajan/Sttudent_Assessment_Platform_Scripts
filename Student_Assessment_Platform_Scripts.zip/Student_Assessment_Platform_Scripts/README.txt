To prepare the backend for Students Assessment Platform, run the following T-SQL scripts IN THE GIVEN ORDER

1.Open SQL Server Management Studio and log in as Administrator
2.Run script "DeleteOldData.sql".  This will delete the old database
objects (from previous versions).
3.Run script "StudentAssessment_backend_objects.sql".  This will create new objects in your now-empty database.
4.Run script "StudentAssessment_backend_objects_Permissions_test.sql".  This will give the user "test" permissions to the new objects created in the database.
5.Run script "CreateSetUsernames.sql".  This will create user names of
dummy users already created for testing purposes.  To be able to log in as them, this must be run.
